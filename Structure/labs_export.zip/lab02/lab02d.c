#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* repeated  (char*  original, int n);

int main(void) {

	printf("%s\n", repeated("bon", 2));
	printf("%s\n", repeated("bon", 3));
	printf("%s\n", repeated("bon", 4));

	return 0;
}

char* repeated  (char*  original, int n) {
	int i, length = strlen(original);
        char*  newString = malloc (sizeof(char) * length * n + 1);
	char*  helper = newString;

	for (i = 0; i < n; i++) {
		strcpy( helper, original);
		helper = helper + length;	
	}
	return newString;
}


